# EasyParking_CM
Repositório de Computação Móvel

Membros: João Miranda nº23416 👨 & Ana Rita Ribeiro nº23754 👩 & Leonardo Andrade nº23415 👨 & José Rafael Rodrigues nº20407 👨 & Miguel Cruzeiro nº23788 👨

Arranjar estacionamento numa cidade nem sempre é fácil e muitas vezes é motivo de perda de tempo para muitos indivíduos. Na cidade de Viana do Castelo existem diversos tipos de estacionamentos, sendo eles parques ou estacionamentos públicos, pagos ou gratuitos. No entanto, muitas das vezes é bastante complicado conseguir arranjar algum estacionamento livre. Por isso mesmo, decidimos criar uma app de estacionamento inteligente que facilitasse esse processo ao utilizador.

Objetivo: Ajudar o utilizador a encontrar o estacionamento adequado a si (incluindo estacionamento para pessoas incapacitadas) e, desta forma, ajudá-lo também a poupar tempo na procura.

Ao utilizar a nossa aplicação, o utilizador poderá ver os diferentes estacionamentos que se encontram livres na cidade de Viana do Castelo, bem como se os mesmos são pagos ou gratuitos.
